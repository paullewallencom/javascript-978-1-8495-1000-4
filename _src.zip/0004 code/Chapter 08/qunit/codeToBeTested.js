function isOdd(value) {
	return value % 2 != 0;
}



function printSomeThing(text) {
	if(text=="")
		return 0;
	else
		return 1;
}

