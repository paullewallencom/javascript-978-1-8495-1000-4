function changeOne(element) {
    var id = element.id;
    var obj = document.getElementById(id);    
    obj.innerHTML = "";
    obj.innerHTML = "<h1>One is changed!</h1>";
    return true;
}

function changeTwo(element) {
    var id = element.id;
    var obj = document.getElementById(id);    
    obj.innerHTML = "";
    obj.innerHTML = "<h1>Two is changed!</h1>";
    return true;
}
function changeThree(element) {
    var id = element.id;
    var obj = document.getElementById(id);    
    obj.innerHTML = "";
    obj.innerHTML = "<h1>Three is changed!</h1>";
    return true;
}